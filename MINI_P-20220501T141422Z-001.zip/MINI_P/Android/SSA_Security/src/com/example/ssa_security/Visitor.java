package com.example.ssa_security;

public class Visitor {

	String visitor_name=null,room_no=null,time_to_visit=null,socity_id=null,time_to_leave=null,mobile_no=null,
				vehical_no=null,gmail=null,security_id=null,status=null,user_id=null,message=null,visitor_id=null;


	public String getSecurity_id() {
		return security_id;
	}

	public String getVisitor_id() {
		return visitor_id;
	}

	public void setVisitor_id(String visitor_id) {
		this.visitor_id = visitor_id;
	}

	public String getVisitor_name() {
		return visitor_name;
	}

	public void setVisitor_name(String visitor_name) {
		this.visitor_name = visitor_name;
	}

	public String getRoom_no() {
		return room_no;
	}

	public void setRoom_no(String room_no) {
		this.room_no = room_no;
	}

	public String getTime_to_visit() {
		return time_to_visit;
	}

	public void setTime_to_visit(String time_to_visit) {
		this.time_to_visit = time_to_visit;
	}

	public String getSocity_id() {
		return socity_id;
	}

	public void setSocity_id(String socity_id) {
		this.socity_id = socity_id;
	}

	public String getTime_to_leave() {
		return time_to_leave;
	}

	public void setTime_to_leave(String time_to_leave) {
		this.time_to_leave = time_to_leave;
	}

	public String getMobile_no() {
		return mobile_no;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	public String getVehical_no() {
		return vehical_no;
	}

	public void setVehical_no(String vehical_no) {
		this.vehical_no = vehical_no;
	}

	public String getGmail() {
		return gmail;
	}

	public void setGmail(String gmail) {
		this.gmail = gmail;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setSecurity_id(String security_id) {
		this.security_id = security_id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}