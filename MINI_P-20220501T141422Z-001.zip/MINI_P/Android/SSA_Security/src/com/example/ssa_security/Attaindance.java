package com.example.ssa_security;

import java.util.ArrayList;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.Menu;
import android.widget.ListView;
import android.widget.Toast;

public class Attaindance extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_attaindance);
		/**
		ArrayList<Staff> arrayList = new ArrayList<Staff>();
		Staff staff = new Staff();
		staff.setStaff_id("12233");
		staff.setAttaindance("");
		staff.setName("Abhishek Shinde");
		staff.setType("Clean");
		arrayList.add(staff);
		Attaindance_plugin attaindance_plugin = new Attaindance_plugin(arrayList, getApplicationContext());
		*/
		ListView listView = (ListView)findViewById(R.id.attendance_unit);
		
	}
	
	public class AsyncAttain extends AsyncTask<String, String, String>{

		@Override
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub
			SharedPreferences preferences = getSharedPreferences("MYKEY", MODE_APPEND);
			String socity_id = preferences.getString("socity_id", "socity_id");
			String site_url_json = "http://10.1.10.105:8000/api/visitor/?socity_id="+socity_id;
			
			return null;
		}
		
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
		}
		
	}

}
