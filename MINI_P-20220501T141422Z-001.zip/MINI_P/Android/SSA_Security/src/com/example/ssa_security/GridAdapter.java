package com.example.ssa_security;
import java.util.zip.Inflater;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class GridAdapter extends BaseAdapter{

	Context ctx;
	String[] name;
	
	public GridAdapter(Context ctx, String[] name) {
		super();
		this.ctx = ctx;
		this.name = name;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return name.length;
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		LayoutInflater inflater = (LayoutInflater) ctx.getSystemService(ctx.LAYOUT_INFLATER_SERVICE);
		convertView = inflater.inflate(R.layout.dashboard_panel, null);
		//Button button =(Button)convertView.findViewById(R.id.button1);
		TextView textView = (TextView)convertView.findViewById(R.id.textView1);
		
		textView.setText(name[position]);
		//button.setText(name[position]);
		
		
		return convertView;
	}

	
}
