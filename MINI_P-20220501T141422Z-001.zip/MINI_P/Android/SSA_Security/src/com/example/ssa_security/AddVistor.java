package com.example.ssa_security;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.telephony.gsm.SmsManager;
import android.view.Menu;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddVistor extends Activity {

	EditText evisitor_name,emobile_no,evehical_no,eroom_no,emessage,egmail;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_vistor);
		evisitor_name = (EditText)findViewById(R.id.visitor_name);
		emobile_no = (EditText)findViewById(R.id.mobile_no);
		egmail = (EditText)findViewById(R.id.gmail);
		evehical_no = (EditText)findViewById(R.id.vehical_no);
		eroom_no = (EditText)findViewById(R.id.room_no);
		emessage = (EditText)findViewById(R.id.message);
		
		Button submit = (Button)findViewById(R.id.submit);
		submit.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String visitor_name = evisitor_name.getText().toString().trim();
				String mobile_no = emobile_no.getText().toString().trim();
				String gmail = egmail.getText().toString().trim();
				String vehical_no = evehical_no.getText().toString().trim();
				String room_no = eroom_no.getText().toString().trim();
				String message = emessage.getText().toString().trim();
				
				new SendVisitorData().execute(visitor_name,mobile_no,gmail,vehical_no,room_no,message);
	                  
			}
		});
	}
	
	public class SendVisitorData extends AsyncTask<String, String, String>{
		
		String vname=null,vmobile_no=null,vmessage=null,vgmail=null;
		@Override
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub
			String line = "";
			try {
                  String site_url_json = "http://10.1.10.105:8000/api/visitor/";
                  URL url = new URL(site_url_json);
                  HttpClient httpclient = new DefaultHttpClient();
                  HttpPost httppost = new HttpPost(site_url_json);
                  SharedPreferences shared = getSharedPreferences("MYKEY",MODE_PRIVATE);
                  String socity_id = shared.getString("socity_id","socity_id");
                  String security_id = shared.getString("security_id","security_id");
                  List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(7);
                  nameValuePairs.add(new BasicNameValuePair("socity_id",socity_id));
                  nameValuePairs.add(new BasicNameValuePair("security_id", security_id));
                  nameValuePairs.add(new BasicNameValuePair("visitor", "add_visitor"));
                  nameValuePairs.add(new BasicNameValuePair("visitor_name", arg0[0]));
                  vname = arg0[0]; 
                  nameValuePairs.add(new BasicNameValuePair("visitor_mob", arg0[1]));
                  vmobile_no = arg0[1];
                  nameValuePairs.add(new BasicNameValuePair("visitor_gmail", arg0[2]));
                  vgmail = arg0[2];
                  nameValuePairs.add(new BasicNameValuePair("visitor_vehical_no", arg0[3]));
                  nameValuePairs.add(new BasicNameValuePair("room_no", arg0[4]));
                  nameValuePairs.add(new BasicNameValuePair("visitor_message", arg0[5]));
                  vmessage = arg0[5];
                  
                  httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                  HttpResponse response = httpclient.execute(httppost);
                  HttpEntity resEntity = response.getEntity();
                  InputStream is = resEntity.getContent();
                  BufferedReader br = new BufferedReader(new InputStreamReader(is));
                  
                  line = br.readLine();
                  
				}catch(Exception e){
					Toast.makeText(getApplicationContext(), "Network Error", Toast.LENGTH_LONG).show();
              }
			
			return line;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			//Toast.makeText(getApplicationContext(), "Data"+result, Toast.LENGTH_LONG).show();
			if (result!=null){
			try {
				JSONObject jsonObject = new JSONObject(result);
				String name = jsonObject.getString("name");
				String visitor_id = jsonObject.getString("visitor_id");
				String mobile_no = jsonObject.getString("mobile_no");
				String alt_mobile_no =jsonObject.getString("alt_mobile_no");
				String gmail = jsonObject.getString("email");
				Toast.makeText(getApplicationContext(), "Data"+name, Toast.LENGTH_LONG).show();
				Intent intent =new Intent(getApplicationContext(),Confirm_Visitor.class);
				intent.putExtra("vname",vname);
				intent.putExtra("visitor_id", visitor_id);
				intent.putExtra("vmobile_no",vmobile_no);
				intent.putExtra("vmessage",vmessage);
				intent.putExtra("vgmail",vgmail);
				intent.putExtra("name",name);
				intent.putExtra("mobile_no",mobile_no);
				intent.putExtra("alt_mobile_no",alt_mobile_no);
				intent.putExtra("gmail",gmail);
				startActivity(intent);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			}
		}
		
	}

}
