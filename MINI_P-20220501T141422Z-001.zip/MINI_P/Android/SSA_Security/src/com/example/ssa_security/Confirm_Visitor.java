package com.example.ssa_security;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Confirm_Visitor extends Activity {

	String name ;
	String mobile_no ;
	String alt_mobile_no ;
	String gmail ;
	String vname ;
	String vmobile_no;
	String vmessage;
	String vgmail;
	String security_id;
	String room_no;
	String visitor_id;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_confirm__visitor);
		
		TextView tname = (TextView)findViewById(R.id.name);
		TextView tcontact1 = (TextView)findViewById(R.id.contact1);
		TextView tcontact2 = (TextView)findViewById(R.id.contact2);
		TextView tvname = (TextView)findViewById(R.id.vname);
		TextView tvcontact = (TextView)findViewById(R.id.vcontact);
		TextView tmessage = (TextView)findViewById(R.id.vmessage);
		
		Button call1 =(Button)findViewById(R.id.call1);
		Button call2 =(Button)findViewById(R.id.call2);
		Button call3 =(Button)findViewById(R.id.call3);
		Button confirm =(Button)findViewById(R.id.confirm);
		Button reject = (Button) findViewById(R.id.reject);
		
		Intent intent = getIntent();
		
		name = intent.getStringExtra("name");
		mobile_no = intent.getStringExtra("mobile_no");
		alt_mobile_no = intent.getStringExtra("alt_mobile_no");
		gmail = intent.getStringExtra("gmail");
		vname = intent.getStringExtra("vname");
		vmobile_no = intent.getStringExtra("vmobile_no");
		vmessage = intent.getStringExtra("vmessage");
		vgmail = intent.getStringExtra("vgmail");
		visitor_id = intent.getStringExtra("visitor_id");
		Toast.makeText(getApplicationContext(), name, Toast.LENGTH_LONG).show();
		
		SharedPreferences sharedPreferences =getPreferences(MODE_APPEND);
		security_id = sharedPreferences.getString("security_id", "security_id");
		//display error  data
		Log.d("Error",name+mobile_no+alt_mobile_no+vname+vmobile_no+vmessage);
		
		//display data
		tname.setText(name);
		tcontact1.setText(mobile_no);
		tcontact2.setText(alt_mobile_no);
		tvname.setText(vname);
		tvcontact.setText(vmobile_no);
		tmessage.setText(vmessage);
		
		
		//call to owner
		call1.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
			Intent call1 = new Intent(Intent.ACTION_CALL);
			call1.setData(Uri.parse("tel:"+mobile_no));
			startActivity(call1);
			}
		});
		call2.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
			Intent call2 = new Intent(Intent.ACTION_CALL);
			call2.setData(Uri.parse("tel:"+alt_mobile_no));
			startActivity(call2);
			}
		});
		//call to visitor
		call3.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
			Intent call3 = new Intent(Intent.ACTION_CALL);
			call3.setData(Uri.parse("tel:"+vmobile_no));
			startActivity(call3);
			}
		});
		confirm.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				// confirm by send message and gmail and redirect to visitor log
				Intent intent = new Intent(getApplicationContext(),Confirm_Visitor.class);
				PendingIntent pendingIntent =PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);
				SmsManager manager = SmsManager.getDefault();
				// do after break
				String MessageToOwner = "Subject : Confirm Visitor \n Owner Name :"+name+"\n Greeting the Name :"+vname+"\n come to visit." +
						"Messgae is "+vmessage+"and \n phone number is "+vmobile_no+"this request made by security guard \n id:"+security_id;
				manager.sendTextMessage(mobile_no, null,MessageToOwner, pendingIntent, null);
				
				String MessageToVisitor ="Subject : Confirm Visitor \n Owner Name :"+name+"\n Greeting....! \n The Name :"+vname+"\n  visited." +
						"Messgae is "+vmessage+"and \n phone number is "+vmobile_no+"this request made by security guard \n id:"+security_id;
				manager.sendTextMessage(vmobile_no, null,MessageToVisitor, pendingIntent, null);
				
				Toast.makeText(getApplicationContext(), "Confirmed", Toast.LENGTH_LONG).show();
				new Confirm(gmail,vgmail).execute("confirm",visitor_id);
			}
		});
		reject.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				// confirm by send message and gmail and redirect to visitor log
				Intent intent = new Intent(getApplicationContext(),Confirm_Visitor.class);
				PendingIntent pendingIntent =PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);
				SmsManager manager = SmsManager.getDefault();
				// do after break
				String MessageToOwner = "Subject : Confirm Visitor \n Owner Name :"+name+"\n Greeting the Name :"+vname+"\n come to visit." +
						"Messgae is "+vmessage+"and \n phone number is "+vmobile_no+"this request made by security guard \n id:"+security_id;
				manager.sendTextMessage(mobile_no, null,MessageToOwner, pendingIntent, null);
				
				String MessageToVisitor ="Subject : Confirm Visitor \n Owner Name :"+name+"\n Greeting....! \n The Name :"+vname+"\n  visited." +
						"Messgae is "+vmessage+"and \n phone number is "+vmobile_no+"this request made by security guard \n id:"+security_id;
				manager.sendTextMessage(vmobile_no, null,MessageToVisitor, pendingIntent, null);
				
				Toast.makeText(getApplicationContext(), "Rejected", Toast.LENGTH_LONG).show();
				Toast.makeText(getApplicationContext(), visitor_id, Toast.LENGTH_LONG).show();
				new Confirm(gmail,vgmail).execute("reject" ,visitor_id);
			}
		});
		
		
	}
	
	private class Confirm extends AsyncTask<String , String , String>{
	
		String gmail,vgmail;
		
		
		public Confirm(String gmail, String vgmail) {
			super();
			this.gmail = gmail;
			this.vgmail = vgmail;
		}
		@Override
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub
			String result = "";
			String site_url_json = "http://10.1.10.105:8000/api/visitor/";
			try {
				URL url = new URL(site_url_json);
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(site_url_json);
            SharedPreferences shared = getSharedPreferences("MYKEY",MODE_PRIVATE);
            String socity_id = shared.getString("socity_id","socity_id");
            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(7);
            nameValuePairs.add(new BasicNameValuePair("socity_id",socity_id));
            nameValuePairs.add(new BasicNameValuePair("visitor",arg0[0]));
            nameValuePairs.add(new BasicNameValuePair("gmail", gmail));
            nameValuePairs.add(new BasicNameValuePair("vgmail", vgmail));
            nameValuePairs.add(new BasicNameValuePair("visitor_id",arg0[1] ));
            
            try {
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			} catch (UnsupportedEncodingException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

            try {
			 HttpResponse httpResponse = httpclient.execute(httppost);
			 InputStream inputStream = httpResponse.getEntity().getContent();
			 BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			 result = reader.readLine().toString();
			 if(!result.equals("")){
				 Intent intent = new Intent(getApplicationContext() , Visitor_log.class);
				 startActivity(intent);
				 
			 }
			 
			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            
			return result;
		}
		
	}
}
