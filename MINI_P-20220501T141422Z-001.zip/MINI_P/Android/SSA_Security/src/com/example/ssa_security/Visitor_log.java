package com.example.ssa_security;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class Visitor_log extends Activity {

	
	ListView listView;
	ArrayList<Visitor> arrayList;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_visitor_log);
		/** String[] room_no = {"807","B1","C1"};
		String[] visitor_name = {"Abhishek Shinde","B2","C2"};
		String[] time_to_visit = {"2022-1-20 30:30:3232","B3","C3"};
		String[] socity_id = {"A1","B1","C1"};
		String[] time_to_leave = {"A1","B1","C1"};
		String[] mobile_no = {"A1","B1","C1"};
		String[] vehical_no = {"A1","B1","C1"};*/
		listView = (ListView)findViewById(R.id.visitot_log);
		
		/**ArrayList<Visitor> arrayList = new ArrayList<Visitor>();
		for(int i =0;i<room_no.length;i++){
			Visitor visitor = new Visitor(visitor_name[i], room_no[i], time_to_visit[i], socity_id[i], time_to_leave[i], mobile_no[i], vehical_no[i]);
			arrayList.add(visitor);
		}*/
		arrayList = new ArrayList<Visitor>();
		new GETVisitorLog().execute();
	}
	
	private class GETVisitorLog extends AsyncTask<String , String , String>{
		
		@Override
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub
			String result = null;
			SharedPreferences preferences = getSharedPreferences("MYKEY", MODE_APPEND);
			String socity_id = preferences.getString("socity_id", "socity_id");
			String site_url_json = "http://10.1.10.105:8000/api/visitor/?socity_id="+socity_id;
			
				URI uri;
				try {
					uri = new URI(site_url_json);
					HttpClient client =new  DefaultHttpClient();
					HttpGet get = new HttpGet();
					get.setURI(uri);
					HttpResponse response = client.execute(get);
					InputStream inputStream = response.getEntity().getContent();
					BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
					String read = bufferedReader.readLine();
					result = read.toString();  
					
				} catch (URISyntaxException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			
			
			return result;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			//Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
			super.onPostExecute(result);
			try {
				JSONArray jsonArray = new JSONArray(result);
				for(int i=0;i<jsonArray.length();i++){
					JSONObject jsonObject = jsonArray.getJSONObject(i);
					Visitor visitor = new Visitor();
					visitor.setVisitor_id(jsonObject.getString("visitor_id"));
					visitor.setGmail(jsonObject.getString("visitor_gmail"));
					visitor.setMobile_no(jsonObject.getString("visitor_mob"));
					visitor.setRoom_no(jsonObject.getString("room_no"));
					visitor.setSocity_id(jsonObject.getString("socity_id"));
					visitor.setTime_to_leave(jsonObject.getString("check_out"));
					visitor.setTime_to_visit(jsonObject.getString("check_in"));
					visitor.setUser_id(jsonObject.getString("user_id"));
					visitor.setSecurity_id(jsonObject.getString("security_id"));
					visitor.setVisitor_name(jsonObject.getString("visitor_name"));
					visitor.setVehical_no(jsonObject.getString("visitor_vehical_no"));
					visitor.setMessage(jsonObject.getString("visitor_message"));
					visitor.setStatus(jsonObject.getString("status"));
					arrayList.add(visitor);
				}
				
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				Toast.makeText(getApplicationContext(),"Exception:"+e, Toast.LENGTH_LONG).show();
			}
			CustomBaseAdapter adapter = new CustomBaseAdapter(getApplicationContext(),arrayList);
			listView.setAdapter(adapter);
			listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
					// TODO Auto-generated method stub
					
					Intent intent = new Intent(getApplicationContext(),Visitor_Info.class);
					
					intent.putExtra("name", arrayList.get(arg2).getVisitor_name());
					intent.putExtra("vehical_no",arrayList.get(arg2).getVehical_no());
					intent.putExtra("mobile_no", arrayList.get(arg2).getMobile_no());
					intent.putExtra("message", arrayList.get(arg2).getMessage());
					intent.putExtra("status", arrayList.get(arg2).getStatus());
					intent.putExtra("visitor_id", arrayList.get(arg2).getVisitor_id());
					intent.putExtra("room_no", arrayList.get(arg2).getRoom_no());
					intent.putExtra("check_in", arrayList.get(arg2).getTime_to_visit());
					intent.putExtra("check_out", arrayList.get(arg2).getTime_to_leave());
					
					startActivity(intent);
				}
			});
		}
	}
	

}
