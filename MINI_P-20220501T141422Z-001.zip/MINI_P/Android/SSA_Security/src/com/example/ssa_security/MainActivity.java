package com.example.ssa_security;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;


import android.net.Uri;
import android.net.Uri.Builder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.InputType;
import android.text.format.Time;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.JsonReader;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
 
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {

	EditText username, passcode;
	ProgressBar pb;
	List<NameValuePair> list;
	SharedPreferences preferences,edit;
	Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        preferences  = getSharedPreferences("SESSION",MODE_PRIVATE);
        edit = getSharedPreferences("MYKEY",MODE_PRIVATE);
        editor = edit.edit();
		Boolean login = preferences.getBoolean("login", false);
		
		if(login){
			// do next task
			Intent intent_dashboard = new Intent(MainActivity.this, Dashboard.class);
			startActivity(intent_dashboard);
		}
		else{
        username = (EditText) findViewById(R.id.username);
        passcode = (EditText) findViewById(R.id.passcode);
        Button submit = (Button) findViewById(R.id.submit);
        CheckBox showPasscode = (CheckBox) findViewById(R.id.showPasscode);
        showPasscode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// show password after checked 
				if(arg0.isChecked()){
					passcode.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
					Toast.makeText(getApplicationContext(),"Password VIsible", Toast.LENGTH_LONG).show();
				}else{
					passcode.setTransformationMethod(PasswordTransformationMethod.getInstance());
					Toast.makeText(getApplicationContext(),"Password Hide", Toast.LENGTH_LONG).show();
				}
				
			}
		});
        submit.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// Submit and check data through API
				// check  user name and password
				if(!username.getText().toString().equals("") && !passcode.getText().toString().equals("")){
					String user = username.getText().toString();
					String password = passcode.getText().toString();
					new APIAsync().execute(user,password);
				}
				else{
					Toast.makeText(getApplicationContext(), "Please enter username and password..!", Toast.LENGTH_LONG).show();
				}
			}
		});
		}
    }
    
    private class APIAsync extends AsyncTask<String, String, String>{
    	 HttpURLConnection urlConnection = null,urlConnection1 = null;
         BufferedReader reader = null;
         //String resultJson = "";
         String user=" ";
         
    	@Override
    	protected String doInBackground(String... arg0){
    		// TODO Auto-generated method stub
    		// cause of error is use reading method one another which cause a error
    		String line = "";
    		this.user =  arg0[0];
    		  try {
                  String site_url_json = "http://10.1.10.105:8000/api/";
                  URL url = new URL(site_url_json);
                  HttpClient httpclient = new DefaultHttpClient();
                  HttpPost httppost = new HttpPost(site_url_json);
                  
                  List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                  nameValuePairs.add(new BasicNameValuePair("login", "true"));
                  nameValuePairs.add(new BasicNameValuePair("user", arg0[0]));
                  nameValuePairs.add(new BasicNameValuePair("password", arg0[1]));
              
                  httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                  HttpResponse response = httpclient.execute(httppost);
                  HttpEntity resEntity = response.getEntity();
                  InputStream is = resEntity.getContent();
                  BufferedReader br = new BufferedReader(new InputStreamReader(is));
                  
                  line = br.readLine();
                  
                  //urlConnection = (HttpURLConnection) url.openConnection();
         
                  //urlConnection.setRequestMethod("GET");
                  //urlConnection.connect();
                  // send data
                  //InputStream inputStream = urlConnection.getInputStream();
                  //StringBuffer buffer = new StringBuffer();
                  

                  //reader = new BufferedReader(new InputStreamReader(inputStream));

                  //line = reader.readLine();
                  
                 /** 
                  while ((line = reader.readLine()) != null) {
                      buffer.append(line);
                  }*/
                  
                  //JSONObject resultJson =  new JSONObject(reader.readLine());//buffer.toString();
    		  }
    	catch(Exception e ){
          	TextView textView = (TextView)findViewById(R.id.showtext);
              textView.setText("Exception:"+e);	
          }
    		  
              return line;//resultJson;
    	}
    	
    	@Override
    	protected void onPostExecute(String result) {
    		// TODO Auto-generated method stub
    		super.onPostExecute(result);
    		pb.setVisibility(View.GONE);	 
                 //JSONArray jsonarray = new JSONArray(result);
                 //JSONObject jsonobj = jsonarray.getJSONObject(2);
                 //String result_json_text =  jsonobj.getString("user");
                 //Log.d("FOR_LOG",result_json_text);

                 //TextView textView = (TextView)findViewById(R.id.showtext);
                 //textView.setText(result);
    		
    		try{
    		 JSONObject jsonObject = new JSONObject(result);
    		 boolean abc = true;
			 if(jsonObject.getString("status").equals("valid")){
				 preferences = getSharedPreferences("SESSION", MODE_PRIVATE);
				 preferences.edit().putBoolean("login", true).commit();
				 Intent intent_dashboard = new Intent(MainActivity.this, Dashboard.class);
				 intent_dashboard.putExtra("user", this.user);
				 String socity_id = jsonObject.getString("socity_id");
				 String security_id = jsonObject.getString("security_id");
				 Toast.makeText(getApplicationContext(), socity_id, Toast.LENGTH_LONG).show();
				 //preferences.edit().putString("socity_id", socity_id);
				 editor.putString("socity_id", socity_id);
				 editor.putString("security_id", security_id);
				 editor.commit();
				 Toast.makeText(getApplicationContext(), socity_id, Toast.LENGTH_LONG).show();
				 startActivity(intent_dashboard);
			 }else{
				 TextView textView = (TextView)findViewById(R.id.showtext);
                 textView.setText("Invalid  Password"+jsonObject.getString("status")); 
			 }
    		}
    		catch(JSONException e){

				 TextView textView = (TextView)findViewById(R.id.showtext);
                textView.setText("Invalid Password Or Check Internet Connection");
    		}
             
    	}
    	
    	@Override
    	protected void onPreExecute() {
    		// TODO Auto-generated method stub
    		super.onPreExecute();
    		pb = (ProgressBar)findViewById(R.id.progressBar1);
       	 	pb.setVisibility(View.VISIBLE);
    	}
    }
        
}
