package com.example.ssa_security;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class CustomBaseAdapter extends BaseAdapter{
	
	Context context;
	ArrayList<Visitor> arrayList;
	/** String[] visitor_name,room_no,time_to_visit,socity_id,time_to_leave,mobile_no,vehical_no;
	
	public CustomBaseAdapter(Context context, String[] visitor_name,
			String[] room_no, String[] time_to_visit, String[] socity_id,
			String[] time_to_leave, String[] mobile_no, String[] vehical_no) {
		super();
		this.context = context;
		this.visitor_name = visitor_name;
		this.room_no = room_no;
		this.time_to_visit = time_to_visit;
		this.socity_id = socity_id;
		this.time_to_leave = time_to_leave;
		this.mobile_no = mobile_no;
		this.vehical_no = vehical_no;
		Toast.makeText(context, "Hello", Toast.LENGTH_LONG).show();
	}
	*/
	public CustomBaseAdapter(Context context, ArrayList<Visitor> arrayList) {
		super();
		this.context = context;
		this.arrayList = arrayList;
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return this.arrayList.size();
	}
	
	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return arrayList.get(arg0);
	}
	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return arg0;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup arg2) {
		// TODO Auto-generated method stub
		
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
		//LayoutInflater.from(getContext())
		convertView = inflater.inflate(R.layout.activity_list_view,null);
		
		TextView eroom_no =(TextView) convertView.findViewById(R.id.room_no);
		TextView evisitor_name =(TextView) convertView.findViewById(R.id.visitor_name);
		TextView etime_to_visit =(TextView) convertView.findViewById(R.id.time_to_visit);
		
		eroom_no.setText(arrayList.get(position).getRoom_no());
		evisitor_name.setText(arrayList.get(position).getVisitor_name());
		etime_to_visit.setText(arrayList.get(position).getTime_to_visit().substring(0, 19));
		
		return convertView;
	}
	
}
