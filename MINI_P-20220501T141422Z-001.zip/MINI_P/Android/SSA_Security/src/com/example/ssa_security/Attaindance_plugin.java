package com.example.ssa_security;

import java.util.ArrayList;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Attaindance_plugin extends BaseAdapter {

	ArrayList<Staff> staffDetail;
	Context context;
	
	public Attaindance_plugin(ArrayList<Staff> staffDetail, Context context) {
		super();
		this.staffDetail = staffDetail;
		this.context = context;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return staffDetail.size();
	}
	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return staffDetail.get(arg0);
	}
	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return arg0;
	}
	@Override
	public View getView(final int position, View arg1, ViewGroup arg2) {
		// TODO Auto-generated method stub
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
		arg1 = inflater.inflate(R.layout.attendance_field,null);
		TextView textView = (TextView)arg1.findViewById(R.id.name_of_staff);
		textView.setText(staffDetail.get(position).getName());
		RadioButton button1 = (RadioButton)arg1.findViewById(R.id.p);
		RadioButton button2 = (RadioButton)arg1.findViewById(R.id.a);
		button1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1){
				staffDetail.get(position).setAttaindance("P");
				Toast.makeText(context,"Present"+ staffDetail.get(position).getAttaindance(), Toast.LENGTH_LONG).show();
				}
			}
		});
		button2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1){
				staffDetail.get(position).setAttaindance("A");
				Toast.makeText(context,"Present"+ staffDetail.get(position).getAttaindance(), Toast.LENGTH_LONG).show();
				}
			}
		});
		
		
		
		
		return arg1;
	}	
}
