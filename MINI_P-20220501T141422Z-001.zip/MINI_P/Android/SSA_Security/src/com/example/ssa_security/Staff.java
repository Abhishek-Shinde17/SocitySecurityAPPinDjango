package com.example.ssa_security;

public class Staff {
	String name , attaindance,type , staff_id;

	public String getStaff_id() {
		return staff_id;
	}

	public void setStaff_id(String staff_id) {
		this.staff_id = staff_id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAttaindance() {
		return attaindance;
	}

	public void setAttaindance(String attaindance) {
		this.attaindance = attaindance;
	}
	
}
