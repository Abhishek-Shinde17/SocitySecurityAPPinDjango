package com.example.ssa_security;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.ListView;

public class Show_owner extends Activity {

	String[] nameandroomno = {"1:abc","1:abc","1:abc","6:6bc","1:abc","1:abc","1:abc","5:abc"};
	ListView listView ; 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_show_owner);
		listView = (ListView) findViewById(R.id.listView1);
		//CustomBaseAdapter customBaseAdapter =new CustomBaseAdapter(getApplicationContext(),);
		//listView.setAdapter(customBaseAdapter);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.show_owner, menu);
		return true;
	}

}
