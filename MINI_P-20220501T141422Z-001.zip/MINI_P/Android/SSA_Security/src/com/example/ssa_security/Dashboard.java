package com.example.ssa_security;
import com.example.ssa_security.R.id;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

public class Dashboard extends Activity {
	
	GridView dashboard;
	SharedPreferences sr;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_dashboard);
		dashboard = (GridView)findViewById(R.id.grid_view);
		String[] name = {"ADD VISITOR","VISITOR LOG","COMPLAINT","MANUAL","ATTAINDANCE","STAFF LOG"};
        GridAdapter adapter = new GridAdapter(getApplicationContext(),name);
        dashboard.setAdapter(adapter);
        dashboard.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        	@Override
        	public void onItemClick(AdapterView<?> arg0, View v, int arg2,
        			long arg3) {
        		// TODO Auto-generated method stub
        		//Toast.makeText(getApplicationContext(),"POSITION : "+arg2, Toast.LENGTH_LONG).show();
        		
        		if(arg2 ==0){
        			Intent intent = new Intent(getApplicationContext(),AddVistor.class);
    				startActivity(intent);	
				}
				if(arg2==1){
					Intent intent = new Intent(getApplicationContext(),Visitor_log.class);
					startActivity(intent);
				}
				if(arg2==2){
					// make for complaint panel
				}
				if(arg2==3){
					Toast.makeText(getApplicationContext(),"POSITION : 3", Toast.LENGTH_LONG).show();
				}
				if(arg2==4){
					Intent intent = new Intent(getApplicationContext(),Attaindance.class);
					startActivity(intent);
				}
				if(arg2==5){
					Toast.makeText(getApplicationContext(),"POSITION : 5", Toast.LENGTH_LONG).show();
				}
        		
        	}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
	 getMenuInflater().inflate(R.menu.main, menu);
		 
		return true;
	}
	

    @Override  
    public boolean onOptionsItemSelected(MenuItem item) {  
       int id = item.getItemId();  
        switch (id){  
            case R.id.logout:
                Toast.makeText(getApplicationContext(),"Item 1 Selected",Toast.LENGTH_LONG).show();
                sr=getSharedPreferences("SESSION",MODE_PRIVATE);
                sr.edit()
                .clear()
                .putBoolean("login",false)
                .commit();
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
				startActivity(intent);
                return true;  
            default:  
                return super.onOptionsItemSelected(item);  
        }  
    }  

}
