package com.example.ssa_security;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Visitor_Info extends Activity {
	TextView  vname , vcontact,vvehical_no ,vmessage ,vroom_no,vcheck_in ,vcheck_out,vstatus;
	Button vcall , check_out;
	String vmobile_no , visitor_id;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_visitor__info);
		
		vname = (TextView)findViewById(R.id.vname);
		vcontact = (TextView)findViewById(R.id.vcontact);
		vvehical_no = (TextView)findViewById(R.id.vvehical_no);
		vmessage =(TextView)findViewById(R.id.vmessage);
		vroom_no = (TextView)findViewById(R.id.vroom_no);
		vcheck_in = (TextView)findViewById(R.id.vcheck_in);
		vcheck_out = (TextView)findViewById(R.id.vcheck_out);
		vstatus = (TextView)findViewById(R.id.vstatus);
		
		vcall = (Button)findViewById(R.id.vcall);
		check_out =(Button)findViewById(R.id.check_out);
		
		Intent intent = getIntent();
		visitor_id = intent.getStringExtra("visitor_id");
		vmobile_no = intent.getStringExtra("mobile_no");
		vname.setText(intent.getStringExtra("name"));
		vcontact.setText(vmobile_no);
		String status = intent.getStringExtra("status");
		vstatus.setText(intent.getStringExtra("status"));
		vvehical_no.setTag(intent.getStringExtra("vehical_no"));
		vmessage.setText(intent.getStringExtra("message"));
		vroom_no.setText(intent.getStringExtra("room_no"));
		vcheck_in.setText(intent.getStringExtra("check_in").substring(0, 16));
		
		String checked = intent.getStringExtra("check_out");
		
		if(!checked.equals("None") || status.equals("reject") ){
		vcheck_out.setText(checked.substring(0,16));
		check_out.setVisibility(View.GONE);
		}
		 
		
		vcall.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent vcall = new Intent(Intent.ACTION_CALL);
				vcall.setData(Uri.parse("tel:"+vmobile_no));
				startActivity(vcall);
			}
		});
		
		check_out.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				new Check_out().execute(); 
			}
		});
		
		
	}
	
	public class Check_out extends AsyncTask<String, String, String>{
		String result = "";
		@Override
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub
			SharedPreferences preferences = getSharedPreferences("MYKEY", MODE_APPEND);
			String socity_id = preferences.getString("socity_id", "socity_id");
			String site_url_json = "http://10.1.10.105:8000/api/visitor/";
			URI uri;
			try {
				URL url = new URL(site_url_json);
                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost(site_url_json);
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(7);
                nameValuePairs.add(new BasicNameValuePair("socity_id",socity_id));
                nameValuePairs.add(new BasicNameValuePair("visitor","check_out"));
                nameValuePairs.add(new BasicNameValuePair("visitor_id",visitor_id));
                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse response = httpclient.execute(httppost);
                HttpEntity resEntity = response.getEntity();
                InputStream is = resEntity.getContent();
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                result = br.readLine().toString();
                if(!result.equals(" ")){
                	Intent intent = new Intent(getApplicationContext() , Visitor_log.class);
                	startActivity(intent);
                	
                }
                
                
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return result;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			
			if(result.equals("{'status':'True'}")){
			Intent intent = new Intent(getApplicationContext(),Dashboard.class);
			startActivity(intent);
			
			}
			
		}
		
	}

}
