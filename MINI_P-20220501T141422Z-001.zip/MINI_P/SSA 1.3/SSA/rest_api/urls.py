from django.urls import path
from . import views

urlpatterns = [
    path('',views.Post.as_view(),name='post_data'),
    path('visitor/',views.Visitor.as_view(),name='visitor'),
    path('owner_list/',views.owner_list.as_view(),name='get_owner_data'),
]
