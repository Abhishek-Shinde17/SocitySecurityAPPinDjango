from django.http import response
from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from rest_framework import serializers
from .searializers import postAPI
from .models import API
from datetime import datetime
from django.http.response import JsonResponse
from rest_framework.parsers import JSONParser 
from rest_framework.decorators import api_view
from firebase_admin import  db,initialize_app,credentials,firestore
from dashboard import views as demo
from rest_framework.views import APIView
from rest_framework.response import Response
import json 
# Create your views here.
fdata = demo.fs
class Post(APIView):
    
    def post(self,request):

        """
        if request.method=="GET":
            serializer = JSONParser().parse(request)
            serializerData = postAPI(data=serializer)
            if serializerData.is_valid():
                serializerData.save()
                return JsonResponse(serializerData.data)
        return HttpResponse(request.POST)
        """
        if request.method == 'POST':
            if request.POST["login"] == "true":
                #post = db.reference().child("SecurityGuardAccess").child(request.POST["user"]).get() #API.objects.all()
                
                for value in  fdata.collection("SecurityGuardAccess").where("uname","==",request.POST["user"]).get():
                    post = value.to_dict()
                    print(post)  
                    if post["password"] == request.POST["password"]:
                        #seralize = postAPI(post,many=True) #(post,many=True)
                        data = {"status":"valid","socity_id":post["socity_id"],"security_id":post["security_id"]} #{"status" :"valid"}
                        print(data)
                        return Response(data) #Response(post)#(seralize.data)
                    else:
                        data = {"status":"invalid"} #{"status" :"invalid"}
                        return Response(data) 
            return Response(data = {"data":"Not Found"})

    def get(self, request):
    

            print(request.GET["socity_id"])
            get = db.reference("visitor_table/"+request.GET["socity_id"]).push()
            val = {
                "id":get.key,
                "socity_id":request.GET["socity_id"],
                "visitor" : "Welcome"
                
                }
            get.set(val)
            
            data = db.reference("visitor_table/"+request.GET["socity_id"])
            values = data.get()
            value =[]
            for key , val in values.items(): 
                value.append(val)
            #values = {"data" :[value.to_dict() for value in fdata.collection("FlatOwnerDetails").get()]}
            return Response(value)
        

# for visitor                  
class Visitor(APIView):
    def post(self , request): 

        if request.POST["visitor"] == "add_visitor":
            data = fdata.collection("FlatOwnerDetails").document(request.POST["socity_id"]+request.POST["room_no"]).get()
            values = data.to_dict()
            if data.exists :
                if values["status"]=="live":
                    user_id = values["mobile_no"]
                    response = values
                elif values["status"]=="rented":
                    data = fdata.collection("RentOwnerDetails").document(request.GET["socity_id"]+request.GET["room_no"]).get()
                    values = data.to_dict()
                    response = values
                    user_id = values["mobile_no"]
                elif values["status"]=="empty":
                    user_id = values["mobile_no"]
                    response = values
            else:
                response = {"status":"invalid"}
                return Response(response)
            
            get = db.reference("visitor_table/"+request.POST["socity_id"]).push()
            visitor_data = {
            "visitor_id":get.key,
            "security_id" : request.POST["security_id"],
            "visitor_name" : request.POST["visitor_name"],
            "visitor_mob" : request.POST["visitor_mob"],
            "visitor_gmail" : request.POST["visitor_gmail"],
            "visitor_message" : request.POST["visitor_message"],
            "visitor_vehical_no" : request.POST["visitor_vehical_no"],
            "check_in" : str(datetime.now()),
            "check_out" : "None",
            "user_id":user_id,
            "room_no":request.POST["room_no"],
            "socity_id":request.POST["socity_id"],
            "status" : "None"
            }
            
            get.set(visitor_data)
            response["visitor_id"]=get.key
            return Response(response)

        
        if request.POST["visitor"]=="confirm":
            #send message and notification to owner and visitor
            data = db.reference("visitor_table/"+request.POST["socity_id"])
            values = data.get()
            for key,value in values.items():
                if value["visitor_id"] == request.POST["visitor_id"]:
                    value["status"]="confirm"
                    response = {'status':True}
                    data.child(value["visitor_id"]).set(value)
                
                    return Response(response)


        
        if request.POST["visitor"]=="reject":
            #send message and notification to owner and visitor
            data = db.reference("visitor_table/"+request.POST["socity_id"])
            values = data.get()
            for key,value in values.items():
                if value["visitor_id"] == request.POST["visitor_id"]:
                    value["status"]="reject"
                    response = {'status': False}
                    data.child(value["visitor_id"]).set(value)
                    
                    return Response(response)
          
        if request.POST["visitor"]=="check_out":
            data = db.reference("visitor_table/"+request.POST["socity_id"])
            values = data.get()
            for key,value in values.items():
                if value["visitor_id"] == request.POST["visitor_id"]:
                    value["check_out"]=str(datetime.now())
                    response = {'status":"True'}
                    data.child(value["visitor_id"]).set(value)
                    
                    return Response(response)
                
        """
            if request.POST["action"] == "add_maid":
                data = {
                    "maid_name" : request.POST["maid_name"],
                    "mobile_no" : request.POST["mobile_no"] ,
                    "socity_id" : request.POST["socity_id"],
                    "room_no"  : request.POST["room_no"],
                    "type"  : request.POST["type"],
                    "last_update": datetime.now(),
                }
                
         """
        return Response({"status":"None"})
    def get(self,request):
        read = db.reference("visitor_table/"+request.GET["socity_id"])
        data = read.get()
        values = []
        if data !=  None:
            for key , value in data.items():
                values.append(value)
            return Response(values)
        else:
            data = {"status":"Invalid ac58cess"}
            return Response(data)

class Ownerlist(APIView):
    def get(self , request):
        value =[]
        data = fdata.collection("FlatOwnerDetails").where("socity_id","==",request.GET["socity_id"]).get()


class ShowNotification(APIView):
    def get(self,request):
            """
            data = {
            "AA":{
                "id":"ABC"
            },
            "BB":{
                "id":"xyz"
            }
            }"""
            """if request.GET["visitor_log"] == "show_visitor":
                data = db.reference("visitor_table").child(request.POST["socity_id"]).get()
                return Response(data)
            """
            #post = [value.to_dict() for value in fdata.collection("SecurityGuardAccess").where("uname","==","gfdgd").get()]
            #data = {"data":post}
            #for value in fdata.collection("SecurityGuardAccess").where("uname","==",request.GET["socity_id"]).get():
                #data = value.to_dict()
            if request.GET["socity_id"]:
                val = {
                    "socity_id":request.GET["socity_id"],
                    "room_no" : request.GET["room_no"],
                    "visitor" : "Welcome"
                    }
                #db.reference("visitor_table").child(request.GET["socity_id"]).child(request.GET["room_no"]).push(val)
                data = db.reference("visitor_table").child(request.GET["socity_id"]).child(request.GET["room_no"]).get()
                
                #values = {"data" :[value.to_dict() for value in fdata.collection("FlatOwnerDetails").get()]}
                return Response(data)
            else:
                data = {"Error":"There id error"}
                return Response(data)
class GETDATA(APIView):
    def get(self , request):
        pass

        
class owner_list(APIView):
    def get(self,request):    
        data = fdata.collection("FlatOwnerDetails").where("socity_id","==",request.GET["socity_id"]).get()
        return Response(data)

