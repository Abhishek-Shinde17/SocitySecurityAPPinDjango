import random 
from firebase_admin import db
from datetime import datetime
from time import time
def token_genrator(user):
    
    digits = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 !@#$^&*()"
    code = "ABCEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    token = " "
    OTP = " "
    
    for i in range(0, 20): 
            token = token + random.choice(digits)
    for i in range(0,6):
        OTP = OTP + random.choice(code)
    
    data = {
        "token":token,
        "user":user,
        "date":str(datetime.now()),
        "time":time(),
        "expiry":time()+3600,
        "OTP" : OTP
    } 
    db.reference().child("resetPassword").push(data)
    return token , OTP

def token_validate(OTP,token):
    pass
