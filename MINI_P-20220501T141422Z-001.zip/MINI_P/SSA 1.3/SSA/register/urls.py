from django.urls import path, include
from django.conf.urls.static import static
from django.conf import settings
from . import views

app_name = 'register'

urlpatterns = [
    path('',views.login),
    path('forgot-password/',views.forgot_password,name="forgot-password"),
    path('login/',views.login,name="login"),
    path('register/',views.register,name="register"),
]
