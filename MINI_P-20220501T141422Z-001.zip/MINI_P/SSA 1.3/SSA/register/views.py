from django.http.response import HttpResponse
from django.shortcuts import render,redirect
from os import path
from django.core.mail import send_mail , BadHeaderError
from django.conf import settings
from matrix_admin import settings as Email
from time import time
from firebase_admin import db
from datetime import datetime
from .token_validator import token_genrator,token_validate

# Create your views here.

def register(request):
    if request.method == 'POST':
        password =request.POST.get("admin_pass")
        c_password =request.POST.get("admin_c_pass")
        socity_id =request.POST.get("socity_id")
        if password == c_password and password !="" and socity_id !="":
            username = request.POST.get("admin_username")
            socity_name =request.POST.get("socity_name")
            name =request.POST.get("admin_name")
            email =request.POST.get("admin_email")
            mobile =request.POST.get("admin_mobile_no")
            dateTime = str(datetime.now())
            # remain from testing
            db.reference().child("SocityRegistration").child(socity_id).set({"socity_id":socity_id,"socity_name":socity_name,"name":name,"email":email,"mobile":mobile,"username":username,"password":password,"last_update":dateTime})
            db.reference().child("SocityLogin").child(username).set({"socity_id":socity_id,"username":username,"password":password})
            return redirect("/register/login/")
        else:
            return render(request,'register/authentication-register.html',{"error":"! Password Do Not Match And Check Socity ID"})
    return render(request,'register/authentication-register.html')

def login(request):
    if request.method=='POST':
        username = request.POST.get("username")
        password = request.POST.get("password")
        #validate the username and password
        users = db.reference("SocityLogin/"+username+"/password").get()
        if users == password:
            data = db.reference().child("SocityLogin/"+username).get()
            request.session["socity_username"]=data["username"]
            request.session["socity_id"]=data["socity_id"]
            request.session["sucess"]=True
            return redirect("/dashboard/")
        else:
            return HttpResponse("<h1>UnAuthorized Access<h1><br><h6>"+username+"is invalid ....!<h6>"+"<br>kindy perform login again")
    return render(request,"register/authentication-login.html")

def forgot_password(request):
    if request.method =="POST":
        email = str(request.POST.get("email"))
        
        read = db.reference("SocityRegistration/")
        data =  read.get()
        for key , value in data.items():
            if value["email"] == email:
                print(email)
                #return HttpResponse("<h1>user {} not exits please <a href='http://192.168.43.199:8000/register/register'>Register</a></h1>".format(email))
                try:
                    token , OTP = token_genrator(email)
                    
                    #send_mail("RESET PASSWORD","OTP : {} reset you password http://192.168.43.199:8000/login/reset_password/{}".format(OTP,token),Email.EMAIL_HOST_USER,[email],fail_silently=False)
                    return HttpResponse("reset you password <a href='http://10.1.10.105:8080/login/reset_password/{}'>Click ME</a>".format(token))
                except BadHeaderError:
                    return HttpResponse("Something went wrong ..!")
        return HttpResponse("<h1>user {} not exits please <a href='http://10.1.10.105:8080/register/register'>Register</a></h1>".format(email))
    return render(request,'register/forget.html')

def reset_password(request,token):
    if request.method == 'POST':
        read = db.reference("/resetPassword/")
        data = read.get()
        for key , value in data.items():
            if value["token"]==token and value["OTP"]==request.POST.get("otp") and value["expiry"] < time() and str(datetime.now())==value["date"]:
                _read = db.reference("SocityRegistration/")
                _data =  _read.get()
                for _key , _value in _data.items():
                    if  value["email"] == _value["email"] and request.POST.get("new_password")==request.POST.get("confirm_password"):
                        _value["password"] = request.POST.get("new_password")
                        _read.child(_data["socity_id"]).set(_value)
                        return redirect("/register/login/")
    return render(request,'register/reset_pass.html')
