# start from here and make commited changes 
# check for security logain and register and make update
# check for rent owner , complaint panel,noticeboard and view profile 
# make final touches
# done all above work before 5:00 pm
from os import path
from django.http.response import HttpResponse
from django.shortcuts import get_object_or_404, render , redirect
from firebase_admin import credentials,firestore,initialize_app,db
from django.conf import settings
from  datetime import datetime

#create firebase connection 
cred =  credentials.Certificate(path.join(settings.BASE_DIR,'serviceAccountKey.json'))
conf = {
    "apiKey": "l4RpWKVmSARJardPinqtUHg1VVShVfTQ9nK3B9b1",
    "authDomain": "socitysecurityapplication.firebaseapp.com",
    "databaseURL": "https://socitysecurityapplication-default-rtdb.firebaseio.com/"
 
}
initialize_app(cred,conf)
fs = firestore.client()

config = []
# session control
# Create your views here.
# only mobile number cause login

def index(request):    
    access = True
    if not request.session["sucess"]:return redirect("/register/login")
    if request.method=='POST':
        socity_id = request.session["socity_id"] 
        security_id = request.POST.get("security_id")
        name = request.POST.get("sname")
        uname = request.POST.get("susername")
        mobile_no = request.POST.get("smobile_no")
        last_update = datetime.now()
        if request.POST.get("spassword")==request.POST.get("sconfirm_pass"):
            password = request.POST.get("spassword")
            data = {"socity_id":socity_id,"security_id":security_id,"name":name,"uname":uname,"mobile_no":mobile_no,"password":password,"access":access,"last_update":last_update}
            fs.collection("SecurityGuardAccess").document(socity_id+uname).set(data)
            
    value = fs.collection("SecurityGuardAccess").where("socity_id","==",request.session["socity_id"]).get()
    sresult = {"result":[val.to_dict for val in value]}
    return render(request, 'dashboard/index.html',sresult)


def change_status(request,username):
    if not request.session["sucess"]:return redirect("/register/login")
    value = fs.collection("SecurityGuardAccess").document(request.session["socity_id"]+username)
    if value.get().exists:
        value.delete()
        return redirect("/dashboard/")
    else: return HttpResponse("<h1>{} Not Found !<h2>".format(username))

    
def attaindance_log(request):
    if not request.session["sucess"]:return redirect("/register/login")
    return render(request, 'dashboard/attaindance_log.html')




def visitor_log(request):
    if not request.session["sucess"]:return redirect("/register/login")
    # write code for display visitor ad work after internet connection
    values =[]
    get = db.reference("visitor_table/"+request.session["socity_id"])
    value = get.get()
    for key , val in  value.items():
        values.append(val)
    return render(request, "dashboard/visitor_log.html",{"values":values})

def control_system(request):
    return render(request , "dashboard/control_system.html")

def control_button(request , pk):
    set = db.reference("control_system/")#+request.session["socity_id"])
    get = set.get()
    data =""
    if pk == "16":
        #if db.reference("control_system/LIGHT"+pk).get() == "OFF":
        data =pk
            
        #if db.reference("control_system/LIGHT"+pk).get() == "ON":
        #    data ="OFF"
        db.reference("control_system/LIGHT"+pk).set(data)
    if pk == "0":
        data = "00"
        db.reference("control_system/LIGHT16").set(data)
    return render(request , "dashboard/control_system.html",{"data":data})


def notification(request):
    if not request.session["sucess"]:return redirect("/register/login")
    if request.method=="POST":
        title = request.POST.get("title")
        message = request.POST.get("message")
        sign = request.POST.get("sign")
        date = str(datetime.now())
        insert = {"title":title,"message":message,"sign":sign,"date":date}
        db.reference("Notice/"+request.session["socity_id"]).push(insert)
    return render(request, "dashboard/notification.html")

def view_notice(request):
    if not request.session["sucess"]:return redirect("/register/login")
    
    values = db.reference().child("Notice").child(request.session["socity_id"]).get()
    values = [value for key , value in values.items()]
    
    return render(request,"dashboard/view_notice.html",{"views":values})




def staf_form(request):
    if not request.session["sucess"]:return redirect("/register/login")
    if request.method == "POST":
        socity_id = request.session["socity_id"] 
        id = request.POST.get("fname")+request.POST.get("contact_no")
        name = request.POST.get("fname")+" "+request.POST.get("mname")+" "+request.POST.get("lname")
        contact = request.POST.get("contact_no")
        alt_contact = request.POST.get("alt_contact_no")
        staff_type = request.POST.get("staff_type")
        start_date = request.POST.get("start_date")
        gender = request.POST.get("gender")
        added = True
        info = {"id":id,"socity_id":socity_id,"name":name,"contact":contact,"alt_contact":alt_contact,"staff_type":staff_type,"start_date":start_date,"gender":gender,"added":added}
        fs.collection("StaffDetails").document(request.session["socity_id"]+id).set(info)
        return redirect("/dashboard/showstaff")
    

    return render(request, "dashboard/staf_form.html")


#  done sucessfully to add flat owner
def add_flat_owner(request):
    if not request.session["sucess"]:return redirect("/register/login")
    if request.method =="POST":
        name = request.POST.get("name")
        socity_id = request.session["socity_id"] 
        mobile_no = request.POST.get("mobile_no")
        alt_mobile_no = request.POST.get("alt_mobile_no")
        email = request.POST["_email"]
        flat_no = request.POST.get("flat_no")
        wing = request.POST.get("wing")
        floor = request.POST.get("floor")
        dateTime = datetime.now()
        owner_id = socity_id+flat_no
        status = "live"
        data = {"name":name,"mobile_no":mobile_no,"email":email,"alt_mobile_no":alt_mobile_no,"flat_no":flat_no,"wing":wing,"floor":floor,"socity_id":socity_id,"last_update":dateTime,"owner_id":owner_id,"status":status}    
        fs.collection("FlatOwnerDetails").document(socity_id+flat_no).set(data)
        return redirect("/dashboard/show-flat")

    cons = {"floor" : range(1,50)}
    return render(request, "dashboard/add_flat_owner.html",cons)



def flat_details(request,pk):
    if not request.session["sucess"]:return redirect("/register/login")
    if request.method =="POST":
        # unit test for update value <Abhishek> <test forword for beta>
        value = fs.collection("FlatOwnerDetails").document(request.session["socity_id"]+pk).get().to_dict()
        value["status"] = request.POST.get("status") if request.POST.get("status") else value["status"]
        value["name"] = request.POST.get("name")
        value["mobile_no"] = request.POST.get("mobile_no")
        value["alt_mobile_no"] = request.POST.get("alt_mobile_no")
        value["email"] = request.POST.get("_email")
        fs.collection("FlatOwnerDetails").document(request.session["socity_id"]+value["flat_no"]).set(value)
    # unit test done sucessfully <Abhishek>
    value = fs.collection("FlatOwnerDetails").document(request.session["socity_id"]+pk).get().to_dict()
    data = fs.collection("RentOwnerDetails").document(request.session["socity_id"]+pk).get().to_dict()
    detail = {"detail":value,"key":pk,"data":data}
    return render(request, "dashboard/flat_details.html",detail)    



# use real time database
def complaint_panel(request):
    return render(request, "dashboard/complaint.html")




def show_flat(request):
    if not request.session["sucess"]:return redirect("/register/login")
    values = fs.collection("FlatOwnerDetails").where("socity_id","==",request.session["socity_id"]).get()
    data = {"owners":[val.to_dict for val in values ]}
    return render(request, "dashboard/show_flat.html",data)

def remove_staff(request,id):
    fs.collection("FlatOwnerDetails").document(request.session["socity_id"]+id).delete()
    return redirect("/dashboard/showstaff")

def view_profile(request):
    if not request.session["sucess"]:return redirect("/register/login")
    value = fs.collection("SocityRegistration").document(request.session["socity_id"]).get().to_dict()
    return render(request,"dashboard/view_profile.html",{"data":value})



def maid_log(request):
    if not request.session["sucess"]:return redirect("/register/login")
    maids = fs.collection("MaidLog").where("security_id","==",request.session["security_id"]).get()
    return render(request, "dashboard/maid_log.html",{"maids":"maid details"})



def showstaff(request):    
    if not request.session["sucess"]:return redirect("/register/login")
    value = fs.collection("StaffDetails").where("socity_id","==",request.session["socity_id"]).get()
    details = {"details":[val.to_dict for val in value]}
    return render(request, "dashboard/showstaff.html",details)

def logout(request):
    if not request.session["sucess"]:return redirect("/register/login")
    request.session["sucess"]=False
    del request.session["socity_username"]
    del request.session["socity_id"]
    return redirect("/register/login")

def myProfile(request):
    if not request.session["sucess"]:return redirect("/register/login")
    if request.method =="POST":
        
        data = {
        "socity_id" : request.session["socity_id"],
        "socity_name" : request.POST.get("socity_name"),
        "secretory_name" : request.POST.get("secretory_name"),
        "contact_no" : request.POST.get("contact_no"),
        "email" : request.POST.get("email"),
        "floors" : request.POST.get("floors"),
        "flats" : request.POST.get("flats"),
        "plot_no" : request.POST.get("plot_no"),
        "sector" : request.POST.get("sector"),
        "land_mark" : request.POST.get("land_mark"),
        "address" : request.POST.get("address"),
        "pin_code" : request.POST.get("pin_code"),
        "district" : request.POST.get("district"),
        "state" : request.POST.get("state")
        }
        fs.collection("SocityRegistration").document(request.session["socity_id"]).set(data)
        return redirect("/dashboard/view-profile")
    value = db.reference("SocityRegistration").child(request.session["socity_id"]).get()
    return render(request,"dashboard/my_profile.html",{"value":value})
#change password
def change_password(request):
    _read = db.reference("SocityRegistration/")
    _data =  _read.get()
    for _key , _value in _data.items():
        if _value["password"]==request.POST.get("old_password"):
            if request.POST.get("new_password") == request.POST.get("confirm_password"):
                _value["password"]=request.POST.get("new_password")
                _read.child(_value["socity_id"]).set(_value)
    
    return render(request , 'dashboard/change_password.html')

# rent owner detail changes <Abhishek>
def rent_owner(request,key):
    if not request.session["sucess"]:return redirect("/register/login")
    if request.method =="POST":
    
        value = fs.collection("FlatOwnerDetails").document(request.session["socity_id"]+key).get().to_dict()
        value["status"] = "rented" 
        rentOwner = {"socity_id" :request.session["socity_id"],
        "name" : request.POST.get("rentowner_name"),
        "mobile_no" : request.POST.get("mobile_no"),
        "alt_mobile_no" : request.POST.get("alt_mobile_no"),
        "flat_no" : value["flat_no"],
        "wing" : value["wing"],
        "floor" : value["floor"],
        "status" : "live",
        "added" : True,
        "last_update" : datetime.now()
        }
        #rentOwner = {"socity_id":socity_id,"name":name,"mobile_no":mobile_no,"alt_mobile_no":alt_mobile_no,"status":status} #<commited unused value verify at final touch>
        fs.collection("FlatOwnerDetails").document(request.session["socity_id"]+key).set(value)
        fs.collection("RentOwnerDetails").document(value["socity_id"]+value["flat_no"]).set(rentOwner)
        
        return redirect("/dashboard/show-flat")
    value = fs.collection("FlatOwnerDetails").document(request.session["socity_id"]+key).get().to_dict()
    detail = {"detail":value}   
    return render(request,"dashboard/rent_owner.html",detail)

# work on it later
def remove_rentowner(request,key):
    fs.collection("RentOwnerDetails").document(request.session["socity_id"]+key).delete()
    value = fs.collection("FlatOwnerDetails").document(request.session["socity_id"]+key).get().to_dict()
    value["status"] = "empty"
    fs.collection("FlatOwnerDetails").document(request.session["socity_id"]+key).set(value)
    return redirect("/dashboard/show-flat")