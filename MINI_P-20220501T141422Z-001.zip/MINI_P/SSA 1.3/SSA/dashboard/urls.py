from django.urls import path
from dashboard import views
from django.conf.urls.static import static
from django.conf import settings

app_name = "dashboard"

urlpatterns = [
    path("", views.index, name="dashboard"),
    path("change_status/<username>", views.change_status, name="change_status"),
    path("attaindance-log/", views.attaindance_log, name="attaindance-log"),
    path("visitor_log/", views.visitor_log, name="visitor_log"),
    path("notice-panel/", views.notification, name="notice-panel"),
    path("staf-form/", views.staf_form, name="staf-form"),
    path("add_flat_owner/", views.add_flat_owner, name="add_flat_owner"),
    path("rent-owner/<key>", views.rent_owner, name="rent-owner"),
    path("my-profile/", views.myProfile, name="my-profile"),
    path("flat-details/<pk>", views.flat_details, name="flat-details"),
    path("complaint/", views.complaint_panel, name="complaint"),
    path("show-flat/", views.show_flat, name="show-flat"),
    path("maid-log/", views.maid_log, name="maid-log"),
    path("showstaff/", views.showstaff, name="showstaff"),
    path("view-notice/", views.view_notice, name="view-notice"),
    path("change-password/", views.change_password, name="change-password"),
    path("view-profile/", views.view_profile, name="view-profile"),
    path("remove_rentowner/<key>", views.remove_rentowner, name="remove_rentowner"),
    path("logout/", views.logout, name="logout"),
    path("control-system/", views.control_system, name="control-system"),
    path("control-button/<str:pk>", views.control_button, name="control-button"),
] 